package com.pablo.tienda.dao.tndimpl;

public class PedidosDAOImplTnd {

}
