package com.pablo.tienda.dao;

public interface IPedidosDAO {

}
