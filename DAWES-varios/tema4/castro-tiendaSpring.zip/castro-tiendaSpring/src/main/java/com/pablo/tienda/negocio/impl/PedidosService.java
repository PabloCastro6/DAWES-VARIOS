package com.pablo.tienda.negocio.impl;

public class PedidosService {
	//Calculo precio total, y pasar por parametro el ClienteProductoDTO
}
